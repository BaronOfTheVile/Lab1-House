/**
 * This class represents a simple picture. You can draw the picture using
 * the draw method. But wait, there's more: being an electronic picture, it
 * can be changed. You can set it to black-and-white display and back to
 * colors (only after it's been drawn, of course).
 *
 * This class was written as an early example for teaching Java with BlueJ.
 * 
 * @author  Michael K�lling and David J. Barnes
 * @version 2011.07.31
 */
public class Picture
{
    private Square wall;
    private Square wall1;
    private Square wall2;
    private Square window;
    private Triangle roof;
    private Circle sun;
    private Square windowOutline;

    /**
     * Constructor for objects of class Picture
     */
    public Picture()
    {
        // nothing to do... instance variables are automatically set to null
    }

    /**
     * Draw this picture.
     */
    public void draw()
    {
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-140);
        wall.moveVertical(20);
        wall.changeSize(60);
        wall.makeVisible();
        
        window = new Square();
        window.changeColor("black");
        window.moveHorizontal(-140);
        window.moveVertical(35);
        window.changeSize(106);
        window.makeVisible();

        roof = new Triangle();  
        roof.changeSize(60, 180);
        roof.moveHorizontal(20);
        roof.moveVertical(-45);
        roof.makeVisible();

        sun = new Circle();
        sun.changeColor("yellow");
        sun.moveHorizontal(100);
        sun.moveVertical(-40);
        sun.changeSize(80);
        sun.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-139);
        wall.moveVertical(36);
        wall.changeSize(20);
        wall.makeVisible();

        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-139);
        wall.moveVertical(57);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-139);
        wall.moveVertical(78);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-139);
        wall.moveVertical(99);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-139);
        wall.moveVertical(120);
        wall.changeSize(20);
        wall.makeVisible();
        
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-118);
        wall.moveVertical(36);
        wall.changeSize(20);
        wall.makeVisible();

        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-118);
        wall.moveVertical(57);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-118);
        wall.moveVertical(78);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-118);
        wall.moveVertical(99);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-118);
        wall.moveVertical(120);
        wall.changeSize(20);
        wall.makeVisible();
        
        
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-97);
        wall.moveVertical(36);
        wall.changeSize(20);
        wall.makeVisible();

        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-97);
        wall.moveVertical(57);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-97);
        wall.moveVertical(78);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-97);
        wall.moveVertical(99);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-97);
        wall.moveVertical(120);
        wall.changeSize(20);
        wall.makeVisible();
        
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-76);
        wall.moveVertical(36);
        wall.changeSize(20);
        wall.makeVisible();

        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-76);
        wall.moveVertical(57);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-76);
        wall.moveVertical(78);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-76);
        wall.moveVertical(99);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-76);
        wall.moveVertical(120);
        wall.changeSize(20);
        wall.makeVisible();
        
        
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-55);
        wall.moveVertical(36);
        wall.changeSize(20);
        wall.makeVisible();

        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-55);
        wall.moveVertical(57);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-55);
        wall.moveVertical(78);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-55);
        wall.moveVertical(99);
        wall.changeSize(20);
        wall.makeVisible();
        
        wall = new Square();
        wall.changeColor("red");
        wall.moveHorizontal(-55);
        wall.moveVertical(120);
        wall.changeSize(20);
        wall.makeVisible();
    }

    /**
     * Change this picture to black/white display
     */
    public void setBlackAndWhite()
    {
        if (wall != null)   // only if it's painted already...
        {
            wall.changeColor("black");
            window.changeColor("white");
            roof.changeColor("black");
            sun.changeColor("black");
        }
    }

    /**
     * Change this picture to use color display
     */
    public void setColor()
    {
        if (wall != null)   // only if it's painted already...
        {
            wall.changeColor("red");
            window.changeColor("black");
            roof.changeColor("green");
            sun.changeColor("yellow");
        }
    }
}
